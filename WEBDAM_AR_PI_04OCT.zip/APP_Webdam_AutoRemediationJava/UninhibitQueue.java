import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Hashtable;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbSQLStatement;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;


public class UninhibitQueue extends MbJavaComputeNode {
	
	//Cache to hold Database Information..
	public static HashMap<String, String> WebDamDataCache2 = new HashMap<String, String>();		
	
	//Main method..
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
		//Object Instantiation..
		MbOutputTerminal     out         = getOutputTerminal("out");		
		MbMessage            inMessage   = inAssembly.getMessage();		
		
		//try block..
		try 
		{
			//Variable Declarations..
			String            queueName,Status,HostName,Channel,QManager,message,timeStamp;
			int               openInputOptions,returnval,Port;
			
			
            //Object Creations and Instantiations..
			Hashtable<String, Object> Properties    = new Hashtable<String, Object>();           
			MbMessage                 outMessage    = new MbMessage();
			MbMessageAssembly         outAssembly   = new MbMessageAssembly(inAssembly, outMessage);
			
			
			//copyMessageHeaders(inMessage,outMessage);			
			MbElement                 outRoot       = outMessage.getRootElement();
			
			outRoot.addAsLastChild(inMessage.getRootElement().getFirstChild().copy());
			
			
			MbElement                 outXMLNSC     = outRoot.createElementAsLastChild("XMLNSC");
			MbElement                 outMsg        = outXMLNSC.createElementAsLastChild(MbElement.TYPE_NAME,"Message",null);
            MbElement                 outInfo       = outMsg.createElementAsLastChild(MbElement.TYPE_NAME,"Information",null);
            MbElement                 outQStatus    = outInfo.createElementAsLastChild(MbElement.TYPE_NAME,"QueueStatus",null);
            
			
			//Variable Assignments..
			Status                   = "Status";
			
			//Queue Open options and Get Options..
			openInputOptions     = MQConstants.MQOO_SET | MQConstants.MQOO_INQUIRE;
			
			
                  
			//Check whether Cache Exists. If Exists Do Nothing else Call CheckDBConnection() function and based on the return value decide further..
			//If returnval is 0 call loadCache() function to load the ccahe. if returnval not equal to 0 throw below User Exception..
			if ( WebDamDataCache2.containsKey(Status))
			{		    	
				// Do Nothing..			
			}
		    else
		    {
		    	returnval         = this.CheckDBConnection(inAssembly,outAssembly);
		    	if(returnval != 0)
		    	{
		    		MbUserException mbue = new MbUserException(this, "evaluate()", "","", "Could not establish connection with ESB_CONFIG table", null);
				    throw mbue;
		    	}
		    	else if(returnval == 0)
		    	{
		    		this.loadCache(inAssembly);
		    	}
		    	
		    }
			
		    
			//Set values from the Cache to the Local Variables which will be passed on to Queue Manager Properties..
			HostName           = WebDamDataCache2.get("HostName");//Ex: njidlesbapp02
		    Port               = Integer.parseInt(WebDamDataCache2.get("Port"));//Ex: 65400
		    Channel            = WebDamDataCache2.get("Channel");//Ex:SYSTEM.DEF.SVRCONN
		    QManager           = WebDamDataCache2.get("QueueManager");//Ex:INQM02D
		    queueName          = WebDamDataCache2.get("QueueName");//Ex:QL.OUT.ESB_ETL.ORDEREXPORT;
		     
          
            //Create a Queue manager Object by passing the parameter as properties and create Queue Object. Query the Queue Depth and store the information in DB.
		    Properties.put("hostname",HostName);
            Properties.put("port",Port);
            Properties.put("channel",Channel);
            MQQueueManager qMgr    = new MQQueueManager(QManager, Properties);
            MQQueue queue       = qMgr.accessQueue(queueName, openInputOptions);   
            returnval = queue.getInhibitGet();
            
            if(returnval == 1)
            {
            	queue.setInhibitGet(MQConstants.MQQA_GET_ALLOWED);  
            	message = "The Queue "+queueName+" Get is UnInhibited";
            }
            else
            {
            	message = "The Queue "+queueName+" Get is Already UnInhibited";
            }
            
            timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
            
            
            outQStatus.createElementAsLastChild(MbElement.TYPE_NAME,"InterfaceName","WEBDAM");
            outQStatus.createElementAsLastChild(MbElement.TYPE_NAME,"StatusCode",queue.getInhibitGet());          
            outQStatus.createElementAsLastChild(MbElement.TYPE_NAME,"StatusMessage",message);
            outQStatus.createElementAsLastChild(MbElement.TYPE_NAME,"TimeStamp",timeStamp);
            
            out.propagate(outAssembly);
       
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}		

	}
	
	
	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException
	{
		MbElement outRoot = outMessage.getRootElement();
		MbElement header = inMessage.getRootElement().getFirstChild();

		while(header != null && header.getNextSibling() != null)
		{
			outRoot.addAsLastChild(header.copy());
			header = header.getNextSibling();
		}
	}
	
	/*****
	 * 
	 * 
	 * @param inAssembly  - Refers to Input Assembly.
	 * @param outAssembly - Refers to Output Assembly.
	 * Retrives IDENTIFIER and ATTRIBUTES from Database table ESB_CONFIG where INTERFACE matches with 'WEBDAM'. If it is able to retrieve values then this function 
	 * returns the value as 0 else -1.
	 * @throws MbException
	 */
	public int CheckDBConnection(MbMessageAssembly inAssembly,MbMessageAssembly outAssembly) throws MbUserException
	{
		try
		{
			String interfaceName          = "WEBDAM";
			String DataSource             = "MSGBUS";
			String SQLStatement           = "SET Environment.DataCache.Webdam[] = (SELECT T.IDENTIFIER,T.ATTRIBUTES FROM Database.dbo.ESB_CONFIG AS T WHERE T.INTERFACE= '"+interfaceName+"');";
			int transactionType           = MbSQLStatement.SQL_TRANSACTION_AUTO;	
			
			
			MbSQLStatement state = createSQLStatement(DataSource, SQLStatement, transactionType);
			state.setThrowExceptionOnDatabaseError(false);
			state.setTreatWarningsAsErrors(true);
			state.select(inAssembly, outAssembly);
			int sqlCode = state.getSQLCode(); 
			//String sqlErrorText = state.getSQLErrorText();
			//String sqlstate = state.getSQLState();
			return sqlCode;
		}
		catch(Exception e)
		{
			MbUserException ue = new MbUserException(this, "evaluate()", "","", e.toString(), null);
		    throw ue;
		}
	}
	
	
	/*****
	 * 
	 * 
	 * @param inAssembly  - Refers to Input Assembly.
	 * Load the Cache Information from Environment to Cache Variable WebDamDataCache2.
	 * This function doesn't return anything.
	 * @throws MbException
	 */
	public void loadCache(MbMessageAssembly inAssembly) throws MbException
	{
			
			String cachePath              = "DataCache/Webdam";
			String identifier             = "IDENTIFIER";
			String attributes             = "ATTRIBUTES";
			String valIdentifier          = "";
			String valAttributes          = "";
			String WDHostName             = "WD_HOSTNAME";
			String WDPort                 = "WD_PORT";
			String WDChannel              = "WD_CHANNEL";
			String WDQMGR                 = "WD_QMANAGER";
			String WDINHQ                 = "WD_INHIBIT_Q";
			
			String HostName               = "HostName";
			String Port                   = "Port";
			String Channel                = "Channel";
			String QMGR                   = "QueueManager";
			String QNM                    = "QueueName";
			
			
			String Status               = "Status";
			String flag                 = "true";
			String brokerName           = getBroker().getName();
			String brokerNo             = brokerName.substring(2,4);
			String brokerNoNEnv         = brokerName.substring(2,5);
					
			MbElement cacheElement = inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath(cachePath);
			
			while(cacheElement != null )
			{
				valIdentifier  = cacheElement.getFirstElementByPath(identifier).getValueAsString();
				valAttributes  = cacheElement.getFirstElementByPath(attributes).getValueAsString();
				
				if(valIdentifier.equalsIgnoreCase(WDHostName))
				{
					WebDamDataCache2.put(HostName, valAttributes.concat(brokerNo));							
				}
				else if(valIdentifier.equalsIgnoreCase(WDPort))
				{
					WebDamDataCache2.put(Port, valAttributes);							
				}
				else if(valIdentifier.equalsIgnoreCase(WDChannel))
				{
					WebDamDataCache2.put(Channel, valAttributes);							
				}	
				else if(valIdentifier.equalsIgnoreCase(WDQMGR))
				{
					WebDamDataCache2.put(QMGR, valAttributes.concat(brokerNoNEnv));							
				}
				else if(valIdentifier.equalsIgnoreCase(WDINHQ))
				{
					WebDamDataCache2.put(QNM, valAttributes);							
				}
				cacheElement = cacheElement.getNextSibling();
			}
			WebDamDataCache2.put(Status, flag);	
		}
	
}
